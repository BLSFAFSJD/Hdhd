import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Coins, Cpu, HardDrive, MemoryStick, ShoppingCart, Loader2 } from "lucide-react";
import { toast } from "sonner";

interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  memory: number | null;
  disk: number | null;
  cpu: number | null;
  databases: number | null;
  backups: number | null;
}

export default function Products() {
  const { user } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [coins, setCoins] = useState(0);
  const [loading, setLoading] = useState(true);
  const [buying, setBuying] = useState<string | null>(null);
  const [serverName, setServerName] = useState("");
  const [showNameInput, setShowNameInput] = useState<string | null>(null);

  useEffect(() => {
    const fetch = async () => {
      const [productsRes, coinsRes] = await Promise.all([
        supabase.from("products").select("*").eq("active", true),
        user
          ? supabase.from("coins").select("balance").eq("user_id", user.id).maybeSingle()
          : Promise.resolve({ data: null }),
      ]);
      if (productsRes.data) setProducts(productsRes.data);
      if (coinsRes.data) setCoins(coinsRes.data.balance);
      setLoading(false);
    };
    fetch();
  }, [user]);

  const handleBuy = async (product: Product) => {
    if (!user || !serverName.trim()) {
      toast.error("Digite um nome para o servidor");
      return;
    }
    if (coins < product.price) {
      toast.error("Saldo insuficiente de coins!");
      return;
    }

    setBuying(product.id);
    try {
      const res = await supabase.functions.invoke("pterodactyl", {
        body: {
          action: "purchase",
          product_id: product.id,
          server_name: serverName.trim(),
        },
      });

      if (res.data?.error) {
        toast.error(res.data.error);
      } else if (res.data?.success) {
        toast.success(res.data.message || "Servidor criado com sucesso!");
        setCoins((c) => c - product.price);
        setShowNameInput(null);
        setServerName("");
      } else if (res.error) {
        toast.error(res.error.message);
      }
    } catch (err: any) {
      toast.error("Erro: " + err.message);
    } finally {
      setBuying(null);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Loja</h1>
          <p className="text-muted-foreground text-sm mt-1">Escolha um plano para seu servidor</p>
        </div>
        <div className="flex items-center gap-2 glass rounded-lg px-4 py-2">
          <Coins className="h-4 w-4 text-coin" />
          <span className="font-bold text-coin">{coins.toLocaleString()}</span>
          <span className="text-muted-foreground text-sm">coins</span>
        </div>
      </div>

      {products.length === 0 ? (
        <div className="glass rounded-xl p-12 text-center">
          <ShoppingCart className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-30" />
          <p className="text-muted-foreground">Nenhum produto disponível</p>
          <p className="text-sm text-muted-foreground">O administrador precisa adicionar produtos</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {products.map((product) => (
            <div key={product.id} className="glass rounded-xl p-6 flex flex-col hover:border-primary/30 transition-colors">
              <h3 className="text-lg font-bold text-foreground">{product.name}</h3>
              {product.description && (
                <p className="text-muted-foreground text-sm mt-1">{product.description}</p>
              )}

              <div className="mt-4 space-y-2 flex-1">
                {product.memory && (
                  <div className="flex items-center gap-2 text-sm text-secondary-foreground">
                    <MemoryStick className="h-3.5 w-3.5 text-primary" />
                    <span>{product.memory} MB RAM</span>
                  </div>
                )}
                {product.disk && (
                  <div className="flex items-center gap-2 text-sm text-secondary-foreground">
                    <HardDrive className="h-3.5 w-3.5 text-primary" />
                    <span>{product.disk} MB Disco</span>
                  </div>
                )}
                {product.cpu && (
                  <div className="flex items-center gap-2 text-sm text-secondary-foreground">
                    <Cpu className="h-3.5 w-3.5 text-primary" />
                    <span>{product.cpu}% CPU</span>
                  </div>
                )}
              </div>

              <div className="mt-6 border-t border-border pt-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-1.5">
                    <Coins className="h-4 w-4 text-coin" />
                    <span className="text-xl font-bold text-coin">{product.price}</span>
                  </div>
                </div>

                {showNameInput === product.id ? (
                  <div className="space-y-2">
                    <Input
                      value={serverName}
                      onChange={(e) => setServerName(e.target.value)}
                      placeholder="Nome do servidor"
                      className="bg-muted border-border text-sm"
                    />
                    <div className="flex gap-2">
                      <Button
                        variant="glow"
                        size="sm"
                        className="flex-1"
                        onClick={() => handleBuy(product)}
                        disabled={buying === product.id}
                      >
                        {buying === product.id ? (
                          <>
                            <Loader2 className="h-3 w-3 animate-spin mr-1" />
                            Criando...
                          </>
                        ) : (
                          "Confirmar"
                        )}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setShowNameInput(null);
                          setServerName("");
                        }}
                      >
                        Cancelar
                      </Button>
                    </div>
                  </div>
                ) : (
                  <Button
                    variant="glow"
                    size="sm"
                    className="w-full"
                    onClick={() => setShowNameInput(product.id)}
                    disabled={coins < product.price}
                  >
                    {coins < product.price ? "Saldo insuficiente" : "Comprar"}
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Users, Shield } from "lucide-react";

interface UserProfile {
  user_id: string;
  username: string | null;
  pterodactyl_id: number | null;
  created_at: string;
}

export default function AdminUsers() {
  const { isAdmin } = useAuth();
  const [profiles, setProfiles] = useState<UserProfile[]>([]);

  useEffect(() => {
    if (!isAdmin) return;
    // Admin policy needed for this - for now shows empty
    supabase.from("profiles").select("*").then(({ data }) => {
      if (data) setProfiles(data);
    });
  }, [isAdmin]);

  if (!isAdmin) return <p className="text-destructive">Acesso negado</p>;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-foreground">Usuários</h1>

      <div className="glass rounded-xl p-6">
        <div className="space-y-2">
          {profiles.map((p) => (
            <div key={p.user_id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
              <div className="flex items-center gap-3">
                <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center text-primary text-sm font-bold">
                  {p.username?.[0]?.toUpperCase() ?? "U"}
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">{p.username ?? "Sem nome"}</p>
                  <p className="text-xs text-muted-foreground font-mono">{p.user_id}</p>
                </div>
              </div>
              <div className="text-xs text-muted-foreground">
                Ptero ID: {p.pterodactyl_id ?? "—"}
              </div>
            </div>
          ))}
          {profiles.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <Users className="h-10 w-10 mx-auto mb-3 opacity-30" />
              <p>Nenhum usuário encontrado</p>
              <p className="text-sm">Nota: Políticas de admin são necessárias para listar todos</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Plus, Loader2, Egg, ChevronDown } from "lucide-react";

interface Nest {
  attributes: { id: number; name: string; description: string };
}

interface EggData {
  attributes: {
    id: number;
    name: string;
    description: string;
    docker_image: string;
    startup: string;
  };
}

interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  memory: number | null;
  disk: number | null;
  cpu: number | null;
  egg_id: number | null;
  nest_id: number | null;
  active: boolean;
}

export default function AdminProducts() {
  const { isAdmin } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [nests, setNests] = useState<Nest[]>([]);
  const [eggs, setEggs] = useState<EggData[]>([]);
  const [loadingNests, setLoadingNests] = useState(false);
  const [loadingEggs, setLoadingEggs] = useState(false);
  const [selectedNest, setSelectedNest] = useState<number | null>(null);
  const [selectedEgg, setSelectedEgg] = useState<EggData | null>(null);

  const [form, setForm] = useState({
    name: "",
    description: "",
    price: 100,
    memory: 1024,
    disk: 5120,
    cpu: 100,
    databases: 1,
    backups: 1,
    allocations: 1,
  });

  const fetchProducts = async () => {
    const { data } = await supabase.from("products").select("*");
    if (data) setProducts(data);
  };

  useEffect(() => {
    if (isAdmin) fetchProducts();
  }, [isAdmin]);

  const fetchNests = async () => {
    setLoadingNests(true);
    try {
      const res = await supabase.functions.invoke("pterodactyl", {
        body: { action: "list_nests" },
      });
      if (res.data?.nests) {
        setNests(res.data.nests);
      } else if (res.data?.error) {
        toast.error(res.data.error);
      }
    } catch (err: any) {
      toast.error("Erro ao buscar nests: " + err.message);
    } finally {
      setLoadingNests(false);
    }
  };

  const fetchEggs = async (nestId: number) => {
    setLoadingEggs(true);
    setSelectedNest(nestId);
    setSelectedEgg(null);
    try {
      const res = await supabase.functions.invoke("pterodactyl", {
        body: { action: "list_eggs", nest_id: nestId },
      });
      if (res.data?.eggs) {
        setEggs(res.data.eggs);
      } else if (res.data?.error) {
        toast.error(res.data.error);
      }
    } catch (err: any) {
      toast.error("Erro ao buscar eggs: " + err.message);
    } finally {
      setLoadingEggs(false);
    }
  };

  const handleOpenForm = () => {
    setShowForm(true);
    if (nests.length === 0) fetchNests();
  };

  const selectEgg = (egg: EggData) => {
    setSelectedEgg(egg);
    setForm((f) => ({
      ...f,
      name: egg.attributes.name,
      description: egg.attributes.description || "",
    }));
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEgg || !selectedNest) {
      toast.error("Selecione um nest e um egg");
      return;
    }

    const { error } = await supabase.from("products").insert({
      name: form.name,
      description: form.description || null,
      price: form.price,
      memory: form.memory,
      disk: form.disk,
      cpu: form.cpu,
      databases: form.databases,
      backups: form.backups,
      allocations: form.allocations,
      egg_id: selectedEgg.attributes.id,
      nest_id: selectedNest,
    });

    if (error) {
      toast.error("Erro ao criar produto: " + error.message);
    } else {
      toast.success("Produto criado!");
      setShowForm(false);
      setSelectedEgg(null);
      setSelectedNest(null);
      setEggs([]);
      fetchProducts();
    }
  };

  if (!isAdmin) return <p className="text-destructive">Acesso negado</p>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-foreground">Gerenciar Produtos</h1>
        <Button variant="glow" size="sm" onClick={handleOpenForm}>
          <Plus className="h-4 w-4 mr-1" />
          Novo Produto
        </Button>
      </div>

      {showForm && (
        <div className="glass rounded-xl p-6 space-y-5">
          <h2 className="text-lg font-semibold text-foreground">Criar Produto</h2>

          {/* Step 1: Select Nest */}
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">
              1. Selecione o Nest
            </label>
            {loadingNests ? (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" /> Carregando nests...
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {nests.map((nest) => (
                  <button
                    key={nest.attributes.id}
                    type="button"
                    onClick={() => fetchEggs(nest.attributes.id)}
                    className={`p-3 rounded-lg text-left text-sm transition-colors border ${
                      selectedNest === nest.attributes.id
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border bg-muted/50 text-foreground hover:border-primary/30"
                    }`}
                  >
                    <p className="font-medium">{nest.attributes.name}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {nest.attributes.description}
                    </p>
                  </button>
                ))}
                {nests.length === 0 && (
                  <p className="col-span-full text-muted-foreground text-sm">
                    Configure o Pterodactyl nas configurações primeiro
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Step 2: Select Egg */}
          {selectedNest && (
            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">
                2. Selecione o Egg (Tipo de Servidor)
              </label>
              {loadingEggs ? (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" /> Carregando eggs...
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {eggs.map((egg) => (
                    <button
                      key={egg.attributes.id}
                      type="button"
                      onClick={() => selectEgg(egg)}
                      className={`p-3 rounded-lg text-left text-sm transition-colors border ${
                        selectedEgg?.attributes.id === egg.attributes.id
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border bg-muted/50 text-foreground hover:border-primary/30"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <Egg className="h-4 w-4 shrink-0" />
                        <p className="font-medium truncate">{egg.attributes.name}</p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Step 3: Configure product */}
          {selectedEgg && (
            <form onSubmit={handleCreate} className="space-y-4">
              <label className="text-sm font-medium text-foreground mb-2 block">
                3. Configurar Produto
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Nome</label>
                  <Input
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    required
                    className="bg-muted border-border"
                  />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Preço (coins)</label>
                  <Input
                    type="number"
                    value={form.price}
                    onChange={(e) => setForm({ ...form, price: +e.target.value })}
                    required
                    className="bg-muted border-border"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-xs text-muted-foreground mb-1 block">Descrição</label>
                  <Input
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    className="bg-muted border-border"
                  />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">RAM (MB)</label>
                  <Input
                    type="number"
                    value={form.memory}
                    onChange={(e) => setForm({ ...form, memory: +e.target.value })}
                    className="bg-muted border-border"
                  />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Disco (MB)</label>
                  <Input
                    type="number"
                    value={form.disk}
                    onChange={(e) => setForm({ ...form, disk: +e.target.value })}
                    className="bg-muted border-border"
                  />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">CPU (%)</label>
                  <Input
                    type="number"
                    value={form.cpu}
                    onChange={(e) => setForm({ ...form, cpu: +e.target.value })}
                    className="bg-muted border-border"
                  />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Databases</label>
                  <Input
                    type="number"
                    value={form.databases}
                    onChange={(e) => setForm({ ...form, databases: +e.target.value })}
                    className="bg-muted border-border"
                  />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Backups</label>
                  <Input
                    type="number"
                    value={form.backups}
                    onChange={(e) => setForm({ ...form, backups: +e.target.value })}
                    className="bg-muted border-border"
                  />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Allocations</label>
                  <Input
                    type="number"
                    value={form.allocations}
                    onChange={(e) => setForm({ ...form, allocations: +e.target.value })}
                    className="bg-muted border-border"
                  />
                </div>
              </div>

              <div className="bg-muted/50 rounded-lg p-3 text-xs text-muted-foreground">
                <p>
                  <strong className="text-foreground">Egg:</strong> {selectedEgg.attributes.name} (ID: {selectedEgg.attributes.id})
                </p>
                <p>
                  <strong className="text-foreground">Nest:</strong> ID {selectedNest}
                </p>
              </div>

              <Button type="submit" variant="glow">
                Criar Produto
              </Button>
            </form>
          )}
        </div>
      )}

      {/* Products list */}
      <div className="grid gap-3">
        {products.map((p) => (
          <div key={p.id} className="glass rounded-xl p-4 flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-foreground">{p.name}</h3>
              <p className="text-sm text-muted-foreground">
                {p.price} coins · {p.memory} MB RAM · {p.disk} MB Disco · Egg #{p.egg_id}
              </p>
            </div>
            <span
              className={`text-xs font-medium px-2 py-1 rounded-full ${
                p.active ? "bg-success/10 text-success" : "bg-muted text-muted-foreground"
              }`}
            >
              {p.active ? "Ativo" : "Inativo"}
            </span>
          </div>
        ))}
        {products.length === 0 && (
          <p className="text-center text-muted-foreground py-8">Nenhum produto cadastrado</p>
        )}
      </div>
    </div>
  );
}

import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Save, TestTube, CheckCircle, XCircle, Loader2 } from "lucide-react";

export default function AdminSettings() {
  const { isAdmin } = useAuth();
  const [pterodactylUrl, setPterodactylUrl] = useState("");
  const [pterodactylToken, setPterodactylToken] = useState("");
  const [loading, setLoading] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  useEffect(() => {
    if (!isAdmin) return;
    supabase.from("settings").select("*").then(({ data }) => {
      data?.forEach((s) => {
        if (s.key === "pterodactyl_url") setPterodactylUrl(s.value);
        if (s.key === "pterodactyl_token") setPterodactylToken(s.value);
      });
    });
  }, [isAdmin]);

  const handleSave = async () => {
    setLoading(true);
    try {
      for (const { key, value } of [
        { key: "pterodactyl_url", value: pterodactylUrl },
        { key: "pterodactyl_token", value: pterodactylToken },
      ]) {
        const { data: existing } = await supabase
          .from("settings")
          .select("id")
          .eq("key", key)
          .maybeSingle();
        if (existing) {
          await supabase.from("settings").update({ value }).eq("key", key);
        } else {
          await supabase.from("settings").insert({ key, value });
        }
      }
      toast.success("Configurações salvas!");
    } catch {
      toast.error("Erro ao salvar configurações");
    } finally {
      setLoading(false);
    }
  };

  const handleTest = async () => {
    if (!pterodactylUrl || !pterodactylToken) {
      toast.error("Preencha a URL e o Token antes de testar");
      return;
    }
    setTesting(true);
    setTestResult(null);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const res = await supabase.functions.invoke("pterodactyl", {
        body: {
          action: "test_connection",
          pterodactyl_url: pterodactylUrl,
          pterodactyl_token: pterodactylToken,
        },
      });

      if (res.error) {
        setTestResult({ success: false, message: res.error.message });
      } else if (res.data?.error) {
        setTestResult({ success: false, message: res.data.error });
      } else {
        setTestResult({
          success: true,
          message: `${res.data.message} (${res.data.user_count} usuários encontrados)`,
        });
      }
    } catch (err: any) {
      setTestResult({ success: false, message: err.message });
    } finally {
      setTesting(false);
    }
  };

  if (!isAdmin) return <p className="text-destructive">Acesso negado</p>;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-foreground">Configurações</h1>

      <div className="glass rounded-xl p-6 space-y-5 max-w-lg">
        <h2 className="text-lg font-semibold text-foreground">Pterodactyl Panel</h2>

        <div>
          <label className="text-sm font-medium text-foreground mb-1 block">URL do Painel</label>
          <Input
            value={pterodactylUrl}
            onChange={(e) => setPterodactylUrl(e.target.value)}
            placeholder="https://panel.example.com"
            className="bg-muted border-border"
          />
          <p className="text-xs text-muted-foreground mt-1">Ex: https://panel.seudominio.com</p>
        </div>

        <div>
          <label className="text-sm font-medium text-foreground mb-1 block">
            Token da API (Application)
          </label>
          <Input
            type="password"
            value={pterodactylToken}
            onChange={(e) => setPterodactylToken(e.target.value)}
            placeholder="ptlc_..."
            className="bg-muted border-border"
          />
          <p className="text-xs text-muted-foreground mt-1">
            Gere em Admin → Application API no Pterodactyl
          </p>
        </div>

        {/* Test result */}
        {testResult && (
          <div
            className={`flex items-center gap-2 p-3 rounded-lg text-sm ${
              testResult.success
                ? "bg-success/10 text-success"
                : "bg-destructive/10 text-destructive"
            }`}
          >
            {testResult.success ? (
              <CheckCircle className="h-4 w-4 shrink-0" />
            ) : (
              <XCircle className="h-4 w-4 shrink-0" />
            )}
            <span>{testResult.message}</span>
          </div>
        )}

        <div className="flex gap-2">
          <Button variant="outline" onClick={handleTest} disabled={testing}>
            {testing ? (
              <Loader2 className="h-4 w-4 mr-1 animate-spin" />
            ) : (
              <TestTube className="h-4 w-4 mr-1" />
            )}
            Testar Conexão
          </Button>
          <Button variant="glow" onClick={handleSave} disabled={loading}>
            <Save className="h-4 w-4 mr-1" />
            {loading ? "Salvando..." : "Salvar"}
          </Button>
        </div>
      </div>
    </div>
  );
}

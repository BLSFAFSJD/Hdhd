import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Coins, Plus, Minus } from "lucide-react";

interface UserCoins {
  user_id: string;
  balance: number;
  email?: string;
}

export default function AdminCoins() {
  const { isAdmin } = useAuth();
  const [users, setUsers] = useState<UserCoins[]>([]);
  const [selectedUser, setSelectedUser] = useState("");
  const [amount, setAmount] = useState(0);

  useEffect(() => {
    if (!isAdmin) return;
    // Fetch all coins with profiles
    const fetchUsers = async () => {
      const { data } = await supabase.from("coins").select("user_id, balance");
      if (data) setUsers(data);
    };
    fetchUsers();
  }, [isAdmin]);

  const modifyCoins = async (userId: string, delta: number) => {
    if (!delta) return;
    const user = users.find((u) => u.user_id === userId);
    if (!user) return;

    const newBalance = user.balance + delta;
    if (newBalance < 0) {
      toast.error("Saldo não pode ser negativo");
      return;
    }

    const { error } = await supabase
      .from("coins")
      .update({ balance: newBalance })
      .eq("user_id", userId);

    if (error) {
      toast.error("Erro: " + error.message);
    } else {
      toast.success(`${delta > 0 ? "Adicionado" : "Removido"} ${Math.abs(delta)} coins`);
      setUsers(users.map((u) => (u.user_id === userId ? { ...u, balance: newBalance } : u)));
    }
  };

  if (!isAdmin) return <p className="text-destructive">Acesso negado</p>;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-foreground">Gerenciar Coins</h1>

      {/* Modify coins */}
      <div className="glass rounded-xl p-6 space-y-4 max-w-lg">
        <h2 className="text-lg font-semibold text-foreground">Modificar Saldo</h2>
        <div>
          <label className="text-sm font-medium text-foreground mb-1 block">User ID</label>
          <Input
            value={selectedUser}
            onChange={(e) => setSelectedUser(e.target.value)}
            placeholder="UUID do usuário"
            className="bg-muted border-border"
          />
        </div>
        <div>
          <label className="text-sm font-medium text-foreground mb-1 block">Quantidade</label>
          <Input
            type="number"
            value={amount}
            onChange={(e) => setAmount(+e.target.value)}
            className="bg-muted border-border"
          />
        </div>
        <div className="flex gap-2">
          <Button variant="glow" size="sm" onClick={() => modifyCoins(selectedUser, amount)}>
            <Plus className="h-4 w-4 mr-1" /> Adicionar
          </Button>
          <Button variant="outline" size="sm" onClick={() => modifyCoins(selectedUser, -amount)}>
            <Minus className="h-4 w-4 mr-1" /> Remover
          </Button>
        </div>
      </div>

      {/* Users list */}
      <div className="glass rounded-xl p-6">
        <h2 className="text-lg font-semibold text-foreground mb-4">Usuários</h2>
        <div className="space-y-2">
          {users.map((u) => (
            <div
              key={u.user_id}
              className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors cursor-pointer"
              onClick={() => setSelectedUser(u.user_id)}
            >
              <span className="text-sm font-mono text-foreground truncate max-w-[200px]">
                {u.user_id}
              </span>
              <div className="flex items-center gap-1.5">
                <Coins className="h-3.5 w-3.5 text-coin" />
                <span className="font-bold text-coin">{u.balance}</span>
              </div>
            </div>
          ))}
          {users.length === 0 && (
            <p className="text-center text-muted-foreground py-4">Nenhum usuário encontrado</p>
          )}
        </div>
      </div>
    </div>
  );
}

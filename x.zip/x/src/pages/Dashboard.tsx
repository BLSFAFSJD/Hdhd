import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Coins, Server, ShoppingCart, TrendingUp } from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();
  const [coins, setCoins] = useState(0);
  const [serverCount, setServerCount] = useState(0);

  useEffect(() => {
    if (!user) return;

    const fetchData = async () => {
      const [coinsRes, serversRes] = await Promise.all([
        supabase.from("coins").select("balance").eq("user_id", user.id).maybeSingle(),
        supabase.from("servers").select("id").eq("user_id", user.id),
      ]);
      if (coinsRes.data) setCoins(coinsRes.data.balance);
      if (serversRes.data) setServerCount(serversRes.data.length);
    };
    fetchData();
  }, [user]);

  const stats = [
    {
      label: "Saldo de Coins",
      value: coins.toLocaleString(),
      icon: Coins,
      color: "text-coin",
      bg: "bg-coin/10",
    },
    {
      label: "Servidores Ativos",
      value: serverCount,
      icon: Server,
      color: "text-primary",
      bg: "bg-primary/10",
    },
    {
      label: "Produtos Disponíveis",
      value: "—",
      icon: ShoppingCart,
      color: "text-accent",
      bg: "bg-accent/10",
    },
    {
      label: "Status",
      value: "Online",
      icon: TrendingUp,
      color: "text-success",
      bg: "bg-success/10",
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Bem-vindo de volta, {user?.email?.split("@")[0] ?? "usuário"}
        </p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <div
            key={stat.label}
            className="glass rounded-xl p-5 hover:border-primary/30 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className={`${stat.bg} rounded-lg p-2.5`}>
                <stat.icon className={`h-5 w-5 ${stat.color}`} />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
                <p className="text-xl font-bold text-foreground">{stat.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent activity placeholder */}
      <div className="glass rounded-xl p-6">
        <h2 className="text-lg font-semibold text-foreground mb-4">Atividade Recente</h2>
        <div className="text-center py-8 text-muted-foreground">
          <Server className="h-10 w-10 mx-auto mb-3 opacity-30" />
          <p>Nenhuma atividade recente</p>
          <p className="text-sm">Compre um produto para criar seu primeiro servidor</p>
        </div>
      </div>
    </div>
  );
}

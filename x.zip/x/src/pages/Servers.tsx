import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Server as ServerIcon, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ServerRow {
  id: string;
  name: string;
  status: string | null;
  pterodactyl_server_id: number | null;
  created_at: string;
}

export default function Servers() {
  const { user } = useAuth();
  const [servers, setServers] = useState<ServerRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [panelUrl, setPanelUrl] = useState("");

  useEffect(() => {
    if (!user) return;

    const fetchData = async () => {
      const [serversRes, settingsRes] = await Promise.all([
        supabase.from("servers").select("*").eq("user_id", user.id),
        supabase.from("settings").select("*"),
      ]);
      if (serversRes.data) setServers(serversRes.data);
      // Try to get panel URL from settings (may fail if not admin, that's ok)
      // We'll store it in a public way later, for now try
      settingsRes.data?.forEach((s) => {
        if (s.key === "pterodactyl_url") setPanelUrl(s.value);
      });
      setLoading(false);
    };
    fetchData();
  }, [user]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Meus Servidores</h1>
        <p className="text-muted-foreground text-sm mt-1">Gerencie seus servidores</p>
      </div>

      {servers.length === 0 ? (
        <div className="glass rounded-xl p-12 text-center">
          <ServerIcon className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-30" />
          <p className="text-muted-foreground">Nenhum servidor encontrado</p>
          <p className="text-sm text-muted-foreground">
            Compre um produto na loja para criar seu primeiro servidor
          </p>
        </div>
      ) : (
        <div className="grid gap-4">
          {servers.map((server) => (
            <div
              key={server.id}
              className="glass rounded-xl p-5 flex items-center gap-4 hover:border-primary/30 transition-colors"
            >
              <div className="bg-primary/10 rounded-lg p-3">
                <ServerIcon className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-foreground">{server.name}</h3>
                <p className="text-sm text-muted-foreground">
                  Pterodactyl ID: {server.pterodactyl_server_id ?? "—"}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span
                  className={`text-xs font-medium px-2.5 py-1 rounded-full ${
                    server.status === "active"
                      ? "bg-success/10 text-success"
                      : "bg-muted text-muted-foreground"
                  }`}
                >
                  {server.status === "active" ? "Ativo" : server.status ?? "—"}
                </span>
                {server.pterodactyl_server_id && panelUrl && (
                  <a
                    href={`${panelUrl.replace(/\/$/, "")}/server/${server.pterodactyl_server_id}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Button variant="outline" size="sm">
                      <ExternalLink className="h-3.5 w-3.5 mr-1" />
                      Gerenciar
                    </Button>
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

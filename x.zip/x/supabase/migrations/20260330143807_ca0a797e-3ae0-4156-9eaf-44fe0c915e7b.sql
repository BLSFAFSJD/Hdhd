
-- Allow all authenticated users to read the pterodactyl_url setting (non-sensitive)
CREATE POLICY "Authenticated users can read pterodactyl_url"
ON public.settings FOR SELECT TO authenticated
USING (key = 'pterodactyl_url');

-- Allow admin to read all profiles (for admin users page)
CREATE POLICY "Admins can view all profiles"
ON public.profiles FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Allow service role to insert coins/servers/transactions (edge function uses service role, but just in case)
-- These are needed for the edge function purchase flow

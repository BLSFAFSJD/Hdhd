import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Verify auth
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Not authenticated" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    const { action } = body;

    // Get Pterodactyl settings
    const getSettings = async () => {
      const { data: settings } = await supabase.from("settings").select("*");
      const map: Record<string, string> = {};
      settings?.forEach((s: any) => { map[s.key] = s.value; });
      return map;
    };

    // Helper to call Pterodactyl API
    const pteroFetch = async (
      url: string,
      token: string,
      method = "GET",
      body?: any
    ) => {
      const opts: RequestInit = {
        method,
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };
      if (body) opts.body = JSON.stringify(body);
      const res = await fetch(url, opts);
      const data = await res.json();
      if (!res.ok) {
        throw new Error(
          `Pterodactyl API error [${res.status}]: ${JSON.stringify(data)}`
        );
      }
      return data;
    };

    // Check if user is admin
    const { data: roleData } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .eq("role", "admin")
      .maybeSingle();
    const isAdmin = !!roleData;

    switch (action) {
      // ==================== TEST CONNECTION ====================
      case "test_connection": {
        if (!isAdmin) {
          return new Response(JSON.stringify({ error: "Admin only" }), {
            status: 403,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        const { pterodactyl_url, pterodactyl_token } = body;
        if (!pterodactyl_url || !pterodactyl_token) {
          return new Response(
            JSON.stringify({ error: "URL and token are required" }),
            {
              status: 400,
              headers: { ...corsHeaders, "Content-Type": "application/json" },
            }
          );
        }

        const baseUrl = pterodactyl_url.replace(/\/$/, "");
        const data = await pteroFetch(
          `${baseUrl}/api/application/users`,
          pterodactyl_token
        );

        return new Response(
          JSON.stringify({
            success: true,
            message: "Conexão bem-sucedida!",
            user_count: data.meta?.pagination?.total ?? 0,
          }),
          {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          }
        );
      }

      // ==================== LIST NESTS ====================
      case "list_nests": {
        if (!isAdmin) {
          return new Response(JSON.stringify({ error: "Admin only" }), {
            status: 403,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        const settings = await getSettings();
        const baseUrl = settings.pterodactyl_url?.replace(/\/$/, "");
        const apiToken = settings.pterodactyl_token;

        if (!baseUrl || !apiToken) {
          return new Response(
            JSON.stringify({ error: "Pterodactyl não configurado" }),
            {
              status: 400,
              headers: { ...corsHeaders, "Content-Type": "application/json" },
            }
          );
        }

        const data = await pteroFetch(
          `${baseUrl}/api/application/nests`,
          apiToken
        );

        return new Response(JSON.stringify({ nests: data.data }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // ==================== LIST EGGS ====================
      case "list_eggs": {
        if (!isAdmin) {
          return new Response(JSON.stringify({ error: "Admin only" }), {
            status: 403,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        const { nest_id } = body;
        const settings = await getSettings();
        const baseUrl = settings.pterodactyl_url?.replace(/\/$/, "");
        const apiToken = settings.pterodactyl_token;

        if (!baseUrl || !apiToken) {
          return new Response(
            JSON.stringify({ error: "Pterodactyl não configurado" }),
            {
              status: 400,
              headers: { ...corsHeaders, "Content-Type": "application/json" },
            }
          );
        }

        const data = await pteroFetch(
          `${baseUrl}/api/application/nests/${nest_id}/eggs?include=variables`,
          apiToken
        );

        return new Response(JSON.stringify({ eggs: data.data }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // ==================== LIST LOCATIONS ====================
      case "list_locations": {
        if (!isAdmin) {
          return new Response(JSON.stringify({ error: "Admin only" }), {
            status: 403,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        const settings = await getSettings();
        const baseUrl = settings.pterodactyl_url?.replace(/\/$/, "");
        const apiToken = settings.pterodactyl_token;

        if (!baseUrl || !apiToken) {
          return new Response(
            JSON.stringify({ error: "Pterodactyl não configurado" }),
            {
              status: 400,
              headers: { ...corsHeaders, "Content-Type": "application/json" },
            }
          );
        }

        const data = await pteroFetch(
          `${baseUrl}/api/application/locations`,
          apiToken
        );

        return new Response(JSON.stringify({ locations: data.data }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // ==================== LIST NODES ====================
      case "list_nodes": {
        if (!isAdmin) {
          return new Response(JSON.stringify({ error: "Admin only" }), {
            status: 403,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        const settings = await getSettings();
        const baseUrl = settings.pterodactyl_url?.replace(/\/$/, "");
        const apiToken = settings.pterodactyl_token;

        if (!baseUrl || !apiToken) {
          return new Response(
            JSON.stringify({ error: "Pterodactyl não configurado" }),
            {
              status: 400,
              headers: { ...corsHeaders, "Content-Type": "application/json" },
            }
          );
        }

        const data = await pteroFetch(
          `${baseUrl}/api/application/nodes?include=allocations`,
          apiToken
        );

        return new Response(JSON.stringify({ nodes: data.data }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // ==================== PURCHASE PRODUCT ====================
      case "purchase": {
        const { product_id, server_name } = body;
        if (!product_id || !server_name) {
          return new Response(
            JSON.stringify({ error: "product_id and server_name required" }),
            {
              status: 400,
              headers: { ...corsHeaders, "Content-Type": "application/json" },
            }
          );
        }

        const settings = await getSettings();
        const baseUrl = settings.pterodactyl_url?.replace(/\/$/, "");
        const apiToken = settings.pterodactyl_token;

        if (!baseUrl || !apiToken) {
          return new Response(
            JSON.stringify({ error: "Pterodactyl não configurado" }),
            {
              status: 400,
              headers: { ...corsHeaders, "Content-Type": "application/json" },
            }
          );
        }

        // Get product
        const { data: product, error: prodErr } = await supabase
          .from("products")
          .select("*")
          .eq("id", product_id)
          .single();
        if (prodErr || !product) {
          return new Response(
            JSON.stringify({ error: "Produto não encontrado" }),
            {
              status: 404,
              headers: { ...corsHeaders, "Content-Type": "application/json" },
            }
          );
        }

        // Check coins
        const { data: coinData } = await supabase
          .from("coins")
          .select("balance")
          .eq("user_id", user.id)
          .single();
        if (!coinData || coinData.balance < product.price) {
          return new Response(
            JSON.stringify({ error: "Saldo insuficiente" }),
            {
              status: 400,
              headers: { ...corsHeaders, "Content-Type": "application/json" },
            }
          );
        }

        // Get or create Pterodactyl user
        const { data: profile } = await supabase
          .from("profiles")
          .select("pterodactyl_id, username")
          .eq("user_id", user.id)
          .single();

        let pteroUserId = profile?.pterodactyl_id;

        if (!pteroUserId) {
          // Create user on Pterodactyl
          const pteroUser = await pteroFetch(
            `${baseUrl}/api/application/users`,
            apiToken,
            "POST",
            {
              email: user.email,
              username: user.email?.split("@")[0]?.replace(/[^a-z0-9]/gi, "") || "user",
              first_name: profile?.username || "User",
              last_name: "Panel",
            }
          );
          pteroUserId = pteroUser.attributes.id;

          // Save pterodactyl_id
          await supabase
            .from("profiles")
            .update({ pterodactyl_id: pteroUserId })
            .eq("user_id", user.id);
        }

        // Find a free allocation
        const nodesData = await pteroFetch(
          `${baseUrl}/api/application/nodes?include=allocations`,
          apiToken
        );

        let allocationId: number | null = null;
        for (const node of nodesData.data) {
          const allocations = node.attributes.relationships?.allocations?.data || [];
          const free = allocations.find(
            (a: any) => !a.attributes.assigned
          );
          if (free) {
            allocationId = free.attributes.id;
            break;
          }
        }

        if (!allocationId) {
          return new Response(
            JSON.stringify({ error: "Nenhuma alocação disponível. Contate o admin." }),
            {
              status: 400,
              headers: { ...corsHeaders, "Content-Type": "application/json" },
            }
          );
        }

        // Create server on Pterodactyl
        const serverPayload: any = {
          name: server_name,
          user: pteroUserId,
          egg: product.egg_id,
          docker_image: "ghcr.io/pterodactyl/yolks:java_17",
          startup:
            "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}",
          environment: {
            SERVER_JARFILE: "server.jar",
            VANILLA_VERSION: "latest",
          },
          limits: {
            memory: product.memory || 1024,
            swap: 0,
            disk: product.disk || 5120,
            io: 500,
            cpu: product.cpu || 100,
          },
          feature_limits: {
            databases: product.databases || 1,
            backups: product.backups || 1,
            allocations: product.allocations || 1,
          },
          allocation: {
            default: allocationId,
          },
        };

        const pteroServer = await pteroFetch(
          `${baseUrl}/api/application/servers`,
          apiToken,
          "POST",
          serverPayload
        );

        // Deduct coins
        await supabase
          .from("coins")
          .update({ balance: coinData.balance - product.price })
          .eq("user_id", user.id);

        // Record server
        await supabase.from("servers").insert({
          user_id: user.id,
          product_id: product.id,
          pterodactyl_server_id: pteroServer.attributes.id,
          name: server_name,
          status: "active",
        });

        // Record transaction
        await supabase.from("transactions").insert({
          user_id: user.id,
          amount: -product.price,
          type: "purchase",
          description: `Compra: ${product.name}`,
        });

        return new Response(
          JSON.stringify({
            success: true,
            server_id: pteroServer.attributes.id,
            message: "Servidor criado com sucesso!",
          }),
          {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          }
        );
      }

      default:
        return new Response(
          JSON.stringify({ error: `Unknown action: ${action}` }),
          {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          }
        );
    }
  } catch (error: any) {
    console.error("Edge function error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});

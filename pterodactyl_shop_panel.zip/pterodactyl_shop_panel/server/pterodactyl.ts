import axios, { AxiosInstance } from "axios";
import { getPterodactylConfig } from "./db";

let pterodactylClient: AxiosInstance | null = null;

async function getPterodactylClient() {
  if (pterodactylClient) return pterodactylClient;

  const config = await getPterodactylConfig();
  if (!config) {
    throw new Error("Pterodactyl configuration not found");
  }

  pterodactylClient = axios.create({
    baseURL: `${config.panelUrl}/api/application`,
    headers: {
      Authorization: `Bearer ${config.applicationToken}`,
      Accept: "Application/vnd.pterodactyl.v1+json",
      "Content-Type": "application/json",
    },
  });

  return pterodactylClient;
}

/**
 * Criar um novo usuário no Pterodactyl
 */
export async function createPterodactylUser(email: string, username: string) {
  const client = await getPterodactylClient();

  try {
    const response = await client.post("/users", {
      email,
      username,
      first_name: username,
      last_name: "User",
      password: Math.random().toString(36).slice(-16),
    });

    return response.data.attributes;
  } catch (error) {
    console.error("Error creating Pterodactyl user:", error);
    throw error;
  }
}

/**
 * Listar todos os eggs disponíveis
 */
export async function listEggs() {
  const client = await getPterodactylClient();

  try {
    const response = await client.get("/nests");
    const nests = response.data.data;

    const allEggs = [];
    for (const nest of nests) {
      const eggResponse = await client.get(`/nests/${nest.attributes.id}/eggs`);
      allEggs.push(...eggResponse.data.data);
    }

    return allEggs;
  } catch (error) {
    console.error("Error listing eggs:", error);
    throw error;
  }
}

/**
 * Listar alocações disponíveis em um node
 */
export async function listAllocations(nodeId: number) {
  const client = await getPterodactylClient();

  try {
    const response = await client.get(`/nodes/${nodeId}/allocations`);
    return response.data.data;
  } catch (error) {
    console.error("Error listing allocations:", error);
    throw error;
  }
}

/**
 * Criar um novo servidor no Pterodactyl
 */
export async function createPterodactylServer(
  userId: number,
  serverName: string,
  eggId: number,
  nestId: number,
  nodeId: number,
  allocationId: number,
  memoryLimit: number,
  diskLimit: number,
  cpuLimit: number,
  databasesLimit: number,
  allocationsLimit: number,
  backupsLimit: number
) {
  const client = await getPterodactylClient();

  try {
    const response = await client.post("/servers", {
      name: serverName,
      user: userId,
      egg: eggId,
      docker_image: "quay.io/pterodactyl/core:latest",
      startup: "echo 'Server starting...'",
      environment: {},
      limits: {
        memory: memoryLimit,
        swap: 0,
        disk: diskLimit,
        io: 500,
        cpu: cpuLimit,
        threads: null,
        oom_disabled: false,
      },
      feature_limits: {
        databases: databasesLimit,
        allocations: allocationsLimit,
        backups: backupsLimit,
      },
      allocation: {
        default: allocationId,
      },
    });

    return response.data.attributes;
  } catch (error) {
    console.error("Error creating Pterodactyl server:", error);
    throw error;
  }
}

/**
 * Obter informações de um servidor
 */
export async function getPterodactylServer(serverId: number) {
  const client = await getPterodactylClient();

  try {
    const response = await client.get(`/servers/${serverId}`);
    return response.data.attributes;
  } catch (error) {
    console.error("Error getting Pterodactyl server:", error);
    throw error;
  }
}

/**
 * Listar todos os nodes
 */
export async function listNodes() {
  const client = await getPterodactylClient();

  try {
    const response = await client.get("/nodes");
    return response.data.data;
  } catch (error) {
    console.error("Error listing nodes:", error);
    throw error;
  }
}

/**
 * Listar todos os nests
 */
export async function listNests() {
  const client = await getPterodactylClient();

  try {
    const response = await client.get("/nests");
    return response.data.data;
  } catch (error) {
    console.error("Error listing nests:", error);
    throw error;
  }
}

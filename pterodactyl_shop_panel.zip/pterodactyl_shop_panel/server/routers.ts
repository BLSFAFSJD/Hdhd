import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import * as db from "./db";
import * as pterodactyl from "./pterodactyl";

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // Produtos
  products: router({
    list: publicProcedure.query(async () => {
      return await db.getAllProducts();
    }),
    get: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return await db.getProductById(input.id);
    }),
    create: adminProcedure
      .input(
        z.object({
          name: z.string(),
          description: z.string().optional(),
          price: z.number(),
          eggId: z.number(),
          nestId: z.number(),
          nodeId: z.number(),
          allocationId: z.number(),
          memoryLimit: z.number(),
          diskLimit: z.number(),
          cpuLimit: z.number(),
          databasesLimit: z.number().default(1),
          allocationsLimit: z.number().default(1),
          backupsLimit: z.number().default(1),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createProduct(input);
      }),
    update: adminProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().optional(),
          description: z.string().optional(),
          price: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...updates } = input;
        return await db.updateProduct(id, updates);
      }),
    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await db.deleteProduct(input.id);
      }),
  }),

  // Servidores
  servers: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserServers(ctx.user.id);
    }),
    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        const server = await db.getServerById(input.id);
        if (!server || server.userId !== ctx.user.id) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        return server;
      }),
    buy: protectedProcedure
      .input(z.object({ productId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const product = await db.getProductById(input.productId);
        if (!product) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Product not found" });
        }

        const user = await db.getUserById(ctx.user.id);
        if (!user) {
          throw new TRPCError({ code: "NOT_FOUND", message: "User not found" });
        }

        if (user.coins < product.price) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Insufficient coins" });
        }

        try {
          // Criar usuário no Pterodactyl se não existir
          let pterodactylUserId = user.pterodactylUserId || 0;
          if (!user.pterodactylUserId) {
            const pterodactylUser = await pterodactyl.createPterodactylUser(
              user.email || `user_${user.id}@panel.local`,
              `user_${user.id}`
            );
            pterodactylUserId = pterodactylUser.id;
          }

          // Criar servidor no Pterodactyl
          const serverName = `${user.name || `User ${user.id}`} - ${product.name}`;
          const pterodactylServer = await pterodactyl.createPterodactylServer(
            pterodactylUserId,
            serverName,
            product.eggId,
            product.nestId,
            product.nodeId,
            product.allocationId,
            product.memoryLimit,
            product.diskLimit,
            product.cpuLimit,
            product.databasesLimit,
            product.allocationsLimit,
            product.backupsLimit
          );

          // Criar registro do servidor no banco
          const result = await db.createServer({
            userId: ctx.user.id,
            productId: input.productId,
            pterodactylServerId: pterodactylServer.id,
            serverUuid: pterodactylServer.uuid,
            serverName: pterodactylServer.name,
            status: "active",
          });

          // Obter o ID do servidor criado
          const servers = await db.getUserServers(ctx.user.id);
          const newServer = servers[servers.length - 1];

          // Descontar coins
          if (newServer) {
            await db.deductCoins(ctx.user.id, product.price, newServer.id);
          }

          return { success: true, serverId: newServer?.id || 0 };
        } catch (error) {
          console.error("Error buying server:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to create server",
          });
        }
      }),
  }),

  // Coins
  coins: router({
    getBalance: protectedProcedure.query(async ({ ctx }) => {
      const user = await db.getUserById(ctx.user.id);
      return { balance: user?.coins || 0 };
    }),
    add: adminProcedure
      .input(z.object({ userId: z.number(), amount: z.number(), reason: z.string() }))
      .mutation(async ({ input }) => {
        await db.addCoins(input.userId, input.amount, input.reason);
        return { success: true };
      }),
    remove: adminProcedure
      .input(z.object({ userId: z.number(), amount: z.number(), reason: z.string() }))
      .mutation(async ({ input }) => {
        await db.removeCoins(input.userId, input.amount, input.reason);
        return { success: true };
      }),
  }),

  // Transações
  transactions: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserTransactions(ctx.user.id);
    }),
    listAll: adminProcedure.query(async () => {
      return await db.getAllTransactions();
    }),
  }),

  // Usuários
  users: router({
    list: adminProcedure.query(async () => {
      return await db.getAllUsers();
    }),
    makeAdmin: adminProcedure
      .input(z.object({ userId: z.number() }))
      .mutation(async ({ input }) => {
        await db.updateUserRole(input.userId, "admin");
        return { success: true };
      }),
    removeAdmin: adminProcedure
      .input(z.object({ userId: z.number() }))
      .mutation(async ({ input }) => {
        await db.updateUserRole(input.userId, "user");
        return { success: true };
      }),
  }),

  // Configuração Pterodactyl
  pterodactylConfig: router({
    get: adminProcedure.query(async () => {
      return await db.getPterodactylConfig();
    }),
    set: adminProcedure
      .input(
        z.object({
          panelUrl: z.string(),
          applicationToken: z.string(),
          clientToken: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        await db.setPterodactylConfig(input);
        return { success: true };
      }),
    listEggs: adminProcedure.query(async () => {
      try {
        return await pterodactyl.listEggs();
      } catch (error) {
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to list eggs" });
      }
    }),
    listNodes: adminProcedure.query(async () => {
      try {
        return await pterodactyl.listNodes();
      } catch (error) {
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to list nodes" });
      }
    }),
    listNests: adminProcedure.query(async () => {
      try {
        return await pterodactyl.listNests();
      } catch (error) {
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to list nests" });
      }
    }),
    listAllocations: adminProcedure
      .input(z.object({ nodeId: z.number() }))
      .query(async ({ input }) => {
        try {
          return await pterodactyl.listAllocations(input.nodeId);
        } catch (error) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to list allocations" });
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;

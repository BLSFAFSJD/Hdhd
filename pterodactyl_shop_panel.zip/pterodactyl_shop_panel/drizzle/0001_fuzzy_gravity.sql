CREATE TABLE `products` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`price` bigint NOT NULL,
	`eggId` int NOT NULL,
	`nestId` int NOT NULL,
	`nodeId` int NOT NULL,
	`allocationId` int NOT NULL,
	`memoryLimit` int NOT NULL,
	`diskLimit` int NOT NULL,
	`cpuLimit` int NOT NULL,
	`databasesLimit` int NOT NULL DEFAULT 1,
	`allocationsLimit` int NOT NULL DEFAULT 1,
	`backupsLimit` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `products_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `pterodactyl_config` (
	`id` int AUTO_INCREMENT NOT NULL,
	`panelUrl` varchar(255) NOT NULL,
	`applicationToken` text NOT NULL,
	`clientToken` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `pterodactyl_config_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `servers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`productId` int NOT NULL,
	`pterodactylServerId` int NOT NULL,
	`serverUuid` varchar(36) NOT NULL,
	`serverName` varchar(255) NOT NULL,
	`status` enum('creating','active','suspended','deleted') NOT NULL DEFAULT 'creating',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `servers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` enum('purchase','admin_add','admin_remove','refund') NOT NULL,
	`amount` bigint NOT NULL,
	`balanceBefore` bigint NOT NULL,
	`balanceAfter` bigint NOT NULL,
	`description` text,
	`serverId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `transactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `coins` bigint DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `pterodactylUserId` int;
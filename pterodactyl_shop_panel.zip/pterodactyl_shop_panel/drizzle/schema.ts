import { bigint, decimal, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  coins: bigint("coins", { mode: "number" }).default(0).notNull(),
  pterodactylUserId: int("pterodactylUserId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Configuração da integração com Pterodactyl
 */
export const pterodactylConfig = mysqlTable("pterodactyl_config", {
  id: int("id").autoincrement().primaryKey(),
  panelUrl: varchar("panelUrl", { length: 255 }).notNull(),
  applicationToken: text("applicationToken").notNull(),
  clientToken: text("clientToken"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PterodactylConfig = typeof pterodactylConfig.$inferSelect;
export type InsertPterodactylConfig = typeof pterodactylConfig.$inferInsert;

/**
 * Produtos disponíveis na loja
 */
export const products = mysqlTable("products", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  price: bigint("price", { mode: "number" }).notNull(),
  eggId: int("eggId").notNull(),
  nestId: int("nestId").notNull(),
  nodeId: int("nodeId").notNull(),
  allocationId: int("allocationId").notNull(),
  memoryLimit: int("memoryLimit").notNull(),
  diskLimit: int("diskLimit").notNull(),
  cpuLimit: int("cpuLimit").notNull(),
  databasesLimit: int("databasesLimit").default(1).notNull(),
  allocationsLimit: int("allocationsLimit").default(1).notNull(),
  backupsLimit: int("backupsLimit").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;

/**
 * Servidores criados pelos usuários
 */
export const servers = mysqlTable("servers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  productId: int("productId").notNull(),
  pterodactylServerId: int("pterodactylServerId").notNull(),
  serverUuid: varchar("serverUuid", { length: 36 }).notNull(),
  serverName: varchar("serverName", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["creating", "active", "suspended", "deleted"]).default("creating").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Server = typeof servers.$inferSelect;
export type InsertServer = typeof servers.$inferInsert;

/**
 * Histórico de transações de coins
 */
export const transactions = mysqlTable("transactions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["purchase", "admin_add", "admin_remove", "refund"]).notNull(),
  amount: bigint("amount", { mode: "number" }).notNull(),
  balanceBefore: bigint("balanceBefore", { mode: "number" }).notNull(),
  balanceAfter: bigint("balanceAfter", { mode: "number" }).notNull(),
  description: text("description"),
  serverId: int("serverId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, TrendingDown, TrendingUp } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Coins } from "lucide-react";

export default function AdminTransactions() {
  const { data: transactions, isLoading } = trpc.transactions.listAll.useQuery();

  const getTypeColor = (type: string) => {
    switch (type) {
      case "purchase":
        return "bg-red-100 text-red-800";
      case "admin_add":
        return "bg-green-100 text-green-800";
      case "admin_remove":
        return "bg-red-100 text-red-800";
      case "refund":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-slate-100 text-slate-800";
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "purchase":
        return "Compra";
      case "admin_add":
        return "Adicionado";
      case "admin_remove":
        return "Removido";
      case "refund":
        return "Reembolso";
      default:
        return type;
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "purchase":
      case "admin_remove":
        return <TrendingDown className="w-4 h-4" />;
      case "admin_add":
      case "refund":
        return <TrendingUp className="w-4 h-4" />;
      default:
        return <Coins className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-900">Todas as Transações</h2>

      {isLoading ? (
        <div className="flex justify-center py-8">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
        </div>
      ) : !transactions || transactions.length === 0 ? (
        <Card className="bg-slate-50">
          <CardContent className="pt-12 pb-12 text-center">
            <p className="text-slate-600">Nenhuma transação encontrada</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3 max-h-[600px] overflow-y-auto">
          {transactions.map((transaction) => (
            <Card key={transaction.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4 flex-1">
                    <div className="bg-slate-100 p-3 rounded-lg">
                      {getTypeIcon(transaction.type)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold text-slate-900">
                          Usuário ID: {transaction.userId}
                        </h4>
                        <Badge className={getTypeColor(transaction.type)}>
                          {getTypeLabel(transaction.type)}
                        </Badge>
                      </div>
                      <p className="text-sm text-slate-600">
                        {transaction.description || "Sem descrição"}
                      </p>
                      <p className="text-xs text-slate-500 mt-1">
                        {new Date(transaction.createdAt).toLocaleString("pt-BR")}
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="flex items-center justify-end gap-1 mb-1">
                      <span className={`text-lg font-bold ${
                        transaction.type === "purchase" || transaction.type === "admin_remove"
                          ? "text-red-600"
                          : "text-green-600"
                      }`}>
                        {transaction.type === "purchase" || transaction.type === "admin_remove"
                          ? "-"
                          : "+"}
                        {transaction.amount}
                      </span>
                      <Coins className="w-4 h-4 text-yellow-500" />
                    </div>
                    <div className="text-xs text-slate-600">
                      <p>{transaction.balanceBefore} → {transaction.balanceAfter}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

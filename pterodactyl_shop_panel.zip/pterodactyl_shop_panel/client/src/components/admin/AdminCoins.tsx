import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Loader2, Plus, Minus } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";

export default function AdminCoins() {
  const { data: users, isLoading } = trpc.users.list.useQuery();
  const addCoinsMutation = trpc.coins.add.useMutation();
  const removeCoinsMutation = trpc.coins.remove.useMutation();
  const [selectedUser, setSelectedUser] = useState<number | null>(null);
  const [amount, setAmount] = useState("");
  const [reason, setReason] = useState("");
  const [action, setAction] = useState<"add" | "remove">("add");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser || !amount || !reason) {
      toast.error("Preencha todos os campos");
      return;
    }

    try {
      if (action === "add") {
        await addCoinsMutation.mutateAsync({
          userId: selectedUser,
          amount: parseInt(amount),
          reason,
        });
        toast.success("Coins adicionados com sucesso!");
      } else {
        await removeCoinsMutation.mutateAsync({
          userId: selectedUser,
          amount: parseInt(amount),
          reason,
        });
        toast.success("Coins removidos com sucesso!");
      }
      setSelectedUser(null);
      setAmount("");
      setReason("");
    } catch (error) {
      toast.error("Erro ao processar transação");
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-900">Gerenciar Coins</h2>

      {isLoading ? (
        <div className="flex justify-center py-8">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
        </div>
      ) : !users || users.length === 0 ? (
        <Card className="bg-slate-50">
          <CardContent className="pt-12 pb-12 text-center">
            <p className="text-slate-600">Nenhum usuário encontrado</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {users.map((user) => (
            <Card key={user.id}>
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{user.name || `Usuário ${user.id}`}</CardTitle>
                    <p className="text-sm text-slate-600 mt-1">{user.email}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-yellow-500">{user.coins}</p>
                    <p className="text-xs text-slate-600">coins</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex gap-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        size="sm"
                        className="gap-2"
                        onClick={() => {
                          setSelectedUser(user.id);
                          setAction("add");
                        }}
                      >
                        <Plus className="w-4 h-4" />
                        Adicionar Coins
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Adicionar Coins</DialogTitle>
                        <DialogDescription>
                          Adicione coins para {user.name || `Usuário ${user.id}`}
                        </DialogDescription>
                      </DialogHeader>
                      <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                          <label className="text-sm font-medium text-slate-900">Quantidade</label>
                          <Input
                            type="number"
                            value={amount}
                            onChange={(e) => setAmount(e.target.value)}
                            placeholder="100"
                          />
                        </div>
                        <div>
                          <label className="text-sm font-medium text-slate-900">Motivo</label>
                          <Input
                            value={reason}
                            onChange={(e) => setReason(e.target.value)}
                            placeholder="Ex: Bônus de boas-vindas"
                          />
                        </div>
                        <div className="flex gap-3">
                          <Button type="button" variant="outline" className="flex-1" onClick={() => setSelectedUser(null)}>
                            Cancelar
                          </Button>
                          <Button type="submit" className="flex-1" disabled={addCoinsMutation.isPending}>
                            {addCoinsMutation.isPending ? (
                              <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Processando...
                              </>
                            ) : (
                              "Adicionar"
                            )}
                          </Button>
                        </div>
                      </form>
                    </DialogContent>
                  </Dialog>

                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        size="sm"
                        variant="outline"
                        className="gap-2"
                        onClick={() => {
                          setSelectedUser(user.id);
                          setAction("remove");
                        }}
                      >
                        <Minus className="w-4 h-4" />
                        Remover Coins
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Remover Coins</DialogTitle>
                        <DialogDescription>
                          Remova coins de {user.name || `Usuário ${user.id}`}
                        </DialogDescription>
                      </DialogHeader>
                      <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                          <label className="text-sm font-medium text-slate-900">Quantidade</label>
                          <Input
                            type="number"
                            value={amount}
                            onChange={(e) => setAmount(e.target.value)}
                            placeholder="100"
                          />
                        </div>
                        <div>
                          <label className="text-sm font-medium text-slate-900">Motivo</label>
                          <Input
                            value={reason}
                            onChange={(e) => setReason(e.target.value)}
                            placeholder="Ex: Punição"
                          />
                        </div>
                        <div className="flex gap-3">
                          <Button type="button" variant="outline" className="flex-1" onClick={() => setSelectedUser(null)}>
                            Cancelar
                          </Button>
                          <Button type="submit" className="flex-1" disabled={removeCoinsMutation.isPending}>
                            {removeCoinsMutation.isPending ? (
                              <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Processando...
                              </>
                            ) : (
                              "Remover"
                            )}
                          </Button>
                        </div>
                      </form>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

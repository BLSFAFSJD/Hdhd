import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Plus, Trash2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";
import { z } from "zod";

const productSchema = z.object({
  name: z.string().min(1, "Nome é obrigatório"),
  description: z.string().optional(),
  price: z.coerce.number().min(1, "Preço deve ser maior que 0"),
  eggId: z.coerce.number().min(1, "Egg é obrigatório"),
  nestId: z.coerce.number().min(1, "Nest é obrigatório"),
  nodeId: z.coerce.number().min(1, "Node é obrigatório"),
  allocationId: z.coerce.number().min(1, "Alocação é obrigatória"),
  memoryLimit: z.coerce.number().min(128, "Memória mínima é 128MB"),
  diskLimit: z.coerce.number().min(512, "Disco mínimo é 512MB"),
  cpuLimit: z.coerce.number().min(10, "CPU mínima é 10%"),
});

export default function AdminProducts() {
  const { data: products, isLoading } = trpc.products.list.useQuery();
  const { data: eggs } = trpc.pterodactylConfig.listEggs.useQuery();
  const { data: nodes } = trpc.pterodactylConfig.listNodes.useQuery();
  const createMutation = trpc.products.create.useMutation();
  const deleteMutation = trpc.products.delete.useMutation();
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    eggId: "",
    nestId: "",
    nodeId: "",
    allocationId: "",
    memoryLimit: "",
    diskLimit: "",
    cpuLimit: "",
  });

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const validated = productSchema.parse(formData);
      await createMutation.mutateAsync(validated);
      toast.success("Produto criado com sucesso!");
      setOpen(false);
      setFormData({
        name: "",
        description: "",
        price: "",
        eggId: "",
        nestId: "",
        nodeId: "",
        allocationId: "",
        memoryLimit: "",
        diskLimit: "",
        cpuLimit: "",
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.issues[0]?.message || "Erro de validação");
      } else {
        toast.error("Erro ao criar produto");
      }
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("Tem certeza que deseja deletar este produto?")) {
      try {
        await deleteMutation.mutateAsync({ id });
        toast.success("Produto deletado com sucesso!");
      } catch (error) {
        toast.error("Erro ao deletar produto");
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-900">Gerenciar Produtos</h2>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Novo Produto
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Criar Novo Produto</DialogTitle>
              <DialogDescription>Preencha os dados do novo produto</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="text-sm font-medium text-slate-900">Nome</label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Ex: Servidor Minecraft 2GB"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-slate-900">Descrição</label>
                <Textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Descrição do produto"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-slate-900">Preço (Coins)</label>
                  <Input
                    type="number"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                    placeholder="100"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-slate-900">Egg ID</label>
                  <Input
                    type="number"
                    value={formData.eggId}
                    onChange={(e) => setFormData({ ...formData, eggId: e.target.value })}
                    placeholder="1"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-slate-900">Nest ID</label>
                  <Input
                    type="number"
                    value={formData.nestId}
                    onChange={(e) => setFormData({ ...formData, nestId: e.target.value })}
                    placeholder="1"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-slate-900">Node ID</label>
                  <Input
                    type="number"
                    value={formData.nodeId}
                    onChange={(e) => setFormData({ ...formData, nodeId: e.target.value })}
                    placeholder="1"
                  />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-slate-900">Allocation ID</label>
                <Input
                  type="number"
                  value={formData.allocationId}
                  onChange={(e) => setFormData({ ...formData, allocationId: e.target.value })}
                  placeholder="1"
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="text-sm font-medium text-slate-900">Memória (MB)</label>
                  <Input
                    type="number"
                    value={formData.memoryLimit}
                    onChange={(e) => setFormData({ ...formData, memoryLimit: e.target.value })}
                    placeholder="512"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-slate-900">Disco (MB)</label>
                  <Input
                    type="number"
                    value={formData.diskLimit}
                    onChange={(e) => setFormData({ ...formData, diskLimit: e.target.value })}
                    placeholder="1024"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-slate-900">CPU (%)</label>
                  <Input
                    type="number"
                    value={formData.cpuLimit}
                    onChange={(e) => setFormData({ ...formData, cpuLimit: e.target.value })}
                    placeholder="100"
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={() => setOpen(false)}
                >
                  Cancelar
                </Button>
                <Button type="submit" className="flex-1" disabled={createMutation.isPending}>
                  {createMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Criando...
                    </>
                  ) : (
                    "Criar Produto"
                  )}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-8">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
        </div>
      ) : !products || products.length === 0 ? (
        <Card className="bg-slate-50">
          <CardContent className="pt-12 pb-12 text-center">
            <p className="text-slate-600">Nenhum produto criado ainda</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {products.map((product) => (
            <Card key={product.id}>
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{product.name}</CardTitle>
                    <p className="text-sm text-slate-600 mt-1">{product.description}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-slate-900">{product.price}</p>
                    <p className="text-xs text-slate-600">coins</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div>
                    <p className="text-xs text-slate-600">Memória</p>
                    <p className="font-semibold text-slate-900">{product.memoryLimit}MB</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-600">Disco</p>
                    <p className="font-semibold text-slate-900">{product.diskLimit}MB</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-600">CPU</p>
                    <p className="font-semibold text-slate-900">{product.cpuLimit}%</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-600">Egg ID</p>
                    <p className="font-semibold text-slate-900">{product.eggId}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="destructive"
                    size="sm"
                    className="gap-2"
                    onClick={() => handleDelete(product.id)}
                    disabled={deleteMutation.isPending}
                  >
                    <Trash2 className="w-4 h-4" />
                    Deletar
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

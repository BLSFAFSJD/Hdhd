import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Save } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState, useEffect } from "react";
import { toast } from "sonner";

export default function AdminConfig() {
  const { data: config, isLoading } = trpc.pterodactylConfig.get.useQuery();
  const setConfigMutation = trpc.pterodactylConfig.set.useMutation();
  const [formData, setFormData] = useState({
    panelUrl: "",
    applicationToken: "",
    clientToken: "",
  });

  useEffect(() => {
    if (config) {
      setFormData({
        panelUrl: config.panelUrl || "",
        applicationToken: config.applicationToken || "",
        clientToken: config.clientToken || "",
      });
    }
  }, [config]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.panelUrl || !formData.applicationToken) {
      toast.error("Preencha os campos obrigatórios");
      return;
    }

    try {
      await setConfigMutation.mutateAsync(formData);
      toast.success("Configuração salva com sucesso!");
    } catch (error) {
      toast.error("Erro ao salvar configuração");
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-900">Configuração Pterodactyl</h2>

      {isLoading ? (
        <div className="flex justify-center py-8">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
        </div>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Integração com Pterodactyl</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="text-sm font-medium text-slate-900">URL do Painel *</label>
                <Input
                  value={formData.panelUrl}
                  onChange={(e) => setFormData({ ...formData, panelUrl: e.target.value })}
                  placeholder="https://pterodactyl.example.com"
                  required
                />
                <p className="text-xs text-slate-500 mt-1">URL completa do seu painel Pterodactyl</p>
              </div>

              <div>
                <label className="text-sm font-medium text-slate-900">Application Token *</label>
                <Textarea
                  value={formData.applicationToken}
                  onChange={(e) => setFormData({ ...formData, applicationToken: e.target.value })}
                  placeholder="ptla_..."
                  required
                  rows={4}
                />
                <p className="text-xs text-slate-500 mt-1">Token de aplicação para criar servidores e usuários</p>
              </div>

              <div>
                <label className="text-sm font-medium text-slate-900">Client Token (Opcional)</label>
                <Textarea
                  value={formData.clientToken}
                  onChange={(e) => setFormData({ ...formData, clientToken: e.target.value })}
                  placeholder="ptlc_..."
                  rows={4}
                />
                <p className="text-xs text-slate-500 mt-1">Token de cliente para acesso dos usuários</p>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-semibold text-blue-900 mb-2">Como obter os tokens?</h4>
                <ol className="text-sm text-blue-800 space-y-1 list-decimal list-inside">
                  <li>Acesse o painel Pterodactyl como administrador</li>
                  <li>Vá para Admin → API</li>
                  <li>Crie um novo token de aplicação (Application Token)</li>
                  <li>Copie o token completo (começa com ptla_)</li>
                  <li>Opcionalmente, crie um token de cliente (ptlc_)</li>
                </ol>
              </div>

              <div className="flex gap-3">
                <Button type="submit" className="gap-2" disabled={setConfigMutation.isPending}>
                  {setConfigMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Salvando...
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4" />
                      Salvar Configuração
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

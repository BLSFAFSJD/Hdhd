import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Shield, ShieldOff } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function AdminUsers() {
  const { data: users, isLoading } = trpc.users.list.useQuery();
  const makeAdminMutation = trpc.users.makeAdmin.useMutation();
  const removeAdminMutation = trpc.users.removeAdmin.useMutation();

  const handleMakeAdmin = async (userId: number) => {
    try {
      await makeAdminMutation.mutateAsync({ userId });
      toast.success("Usuário promovido a admin!");
    } catch (error) {
      toast.error("Erro ao promover usuário");
    }
  };

  const handleRemoveAdmin = async (userId: number) => {
    try {
      await removeAdminMutation.mutateAsync({ userId });
      toast.success("Permissões de admin removidas!");
    } catch (error) {
      toast.error("Erro ao remover permissões");
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-900">Gerenciar Usuários</h2>

      {isLoading ? (
        <div className="flex justify-center py-8">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
        </div>
      ) : !users || users.length === 0 ? (
        <Card className="bg-slate-50">
          <CardContent className="pt-12 pb-12 text-center">
            <p className="text-slate-600">Nenhum usuário encontrado</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {users.map((user) => (
            <Card key={user.id}>
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      {user.name || `Usuário ${user.id}`}
                      <Badge className={user.role === "admin" ? "bg-purple-100 text-purple-800" : "bg-slate-100 text-slate-800"}>
                        {user.role === "admin" ? "Admin" : "Usuário"}
                      </Badge>
                    </CardTitle>
                    <p className="text-sm text-slate-600 mt-1">{user.email}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-yellow-500">{user.coins}</p>
                    <p className="text-xs text-slate-600">coins</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div>
                    <p className="text-xs text-slate-600">ID</p>
                    <p className="font-semibold text-slate-900">{user.id}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-600">OpenID</p>
                    <p className="font-semibold text-slate-900 text-xs truncate">{user.openId}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-600">Cadastrado em</p>
                    <p className="font-semibold text-slate-900 text-xs">
                      {new Date(user.createdAt).toLocaleDateString("pt-BR")}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-600">Último acesso</p>
                    <p className="font-semibold text-slate-900 text-xs">
                      {new Date(user.lastSignedIn).toLocaleDateString("pt-BR")}
                    </p>
                  </div>
                </div>
                <div className="flex gap-2">
                  {user.role === "admin" ? (
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-2"
                      onClick={() => handleRemoveAdmin(user.id)}
                      disabled={removeAdminMutation.isPending}
                    >
                      <ShieldOff className="w-4 h-4" />
                      Remover Admin
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      className="gap-2"
                      onClick={() => handleMakeAdmin(user.id)}
                      disabled={makeAdminMutation.isPending}
                    >
                      <Shield className="w-4 h-4" />
                      Fazer Admin
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Server, Loader2, ExternalLink } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";

export default function Servers() {
  const { user } = useAuth();
  const { data: servers, isLoading: serversLoading } = trpc.servers.list.useQuery();
  const { data: config } = trpc.pterodactylConfig.get.useQuery();

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800";
      case "creating":
        return "bg-blue-100 text-blue-800";
      case "suspended":
        return "bg-yellow-100 text-yellow-800";
      case "deleted":
        return "bg-red-100 text-red-800";
      default:
        return "bg-slate-100 text-slate-800";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "active":
        return "Ativo";
      case "creating":
        return "Criando...";
      case "suspended":
        return "Suspenso";
      case "deleted":
        return "Deletado";
      default:
        return status;
    }
  };

  const handleManageServer = (serverUuid: string) => {
    if (config?.panelUrl) {
      window.open(`${config.panelUrl}/server/${serverUuid}`, "_blank");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Link href="/">
            <Button variant="ghost" className="mb-4">← Voltar</Button>
          </Link>
          <h1 className="text-4xl font-bold text-slate-900">Meus Servidores</h1>
          <p className="text-slate-600 mt-2">Gerencie seus servidores criados</p>
        </div>

        {/* Servers List */}
        {serversLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          </div>
        ) : !servers || servers.length === 0 ? (
          <Card className="bg-slate-50 border-slate-200">
            <CardContent className="pt-12 pb-12 text-center">
              <Server className="w-12 h-12 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-slate-900 mb-2">Nenhum servidor criado</h3>
              <p className="text-slate-600 mb-4">Você ainda não criou nenhum servidor</p>
              <Link href="/shop">
                <Button>Ir para Loja</Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {servers.map((server) => (
              <Card key={server.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="flex items-center gap-2">
                        <Server className="w-5 h-5 text-blue-600" />
                        {server.serverName}
                      </CardTitle>
                      <CardDescription>UUID: {server.serverUuid}</CardDescription>
                    </div>
                    <Badge className={getStatusColor(server.status)}>
                      {getStatusLabel(server.status)}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-slate-600">ID do Servidor</p>
                      <p className="font-semibold text-slate-900">{server.pterodactylServerId}</p>
                    </div>
                    <div>
                      <p className="text-sm text-slate-600">Produto</p>
                      <p className="font-semibold text-slate-900">ID: {server.productId}</p>
                    </div>
                    <div>
                      <p className="text-sm text-slate-600">Criado em</p>
                      <p className="font-semibold text-slate-900">
                        {new Date(server.createdAt).toLocaleDateString("pt-BR")}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-slate-600">Atualizado em</p>
                      <p className="font-semibold text-slate-900">
                        {new Date(server.updatedAt).toLocaleDateString("pt-BR")}
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      className="flex-1"
                      onClick={() => handleManageServer(server.serverUuid)}
                      disabled={server.status !== "active"}
                    >
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Gerenciar Servidor
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Coins, Package, Server, BarChart3 } from "lucide-react";
import { Link } from "wouter";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { user, isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex flex-col items-center justify-center px-4">
        <div className="text-center max-w-2xl">
          <h1 className="text-5xl font-bold text-white mb-4">Pterodactyl Shop Panel</h1>
          <p className="text-xl text-slate-300 mb-8">
            Venda servidores de forma automatizada com um sistema de moedas virtuais
          </p>
          <a href={getLoginUrl()}>
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
              Fazer Login
            </Button>
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Bem-vindo, {user?.name || "Usuário"}!</h1>
          <p className="text-slate-600">Gerencie seus servidores e moedas virtuais</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600">Seus Coins</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <Coins className="w-5 h-5 text-yellow-500" />
                <span className="text-2xl font-bold text-slate-900">{user?.coins || 0}</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600">Seu Papel</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-slate-900 capitalize">
                {user?.role === "admin" ? "Administrador" : "Usuário"}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600">Data de Cadastro</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm font-medium text-slate-900">
                {user?.createdAt ? new Date(user.createdAt).toLocaleDateString("pt-BR") : "-"}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600">Email</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm font-medium text-slate-900 truncate">{user?.email || "-"}</div>
            </CardContent>
          </Card>
        </div>

        {/* Navigation Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Loja */}
          <Link href="/shop">
            <Card className="cursor-pointer hover:shadow-lg transition-shadow h-full">
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Package className="w-6 h-6 text-blue-600" />
                  <CardTitle>Loja</CardTitle>
                </div>
                <CardDescription>Compre servidores com seus coins</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">Navegue pelos produtos disponíveis e crie novos servidores</p>
              </CardContent>
            </Card>
          </Link>

          {/* Meus Servidores */}
          <Link href="/servers">
            <Card className="cursor-pointer hover:shadow-lg transition-shadow h-full">
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Server className="w-6 h-6 text-green-600" />
                  <CardTitle>Meus Servidores</CardTitle>
                </div>
                <CardDescription>Gerencie seus servidores criados</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">Veja o status e acesse o painel de controle dos seus servidores</p>
              </CardContent>
            </Card>
          </Link>

          {/* Transações */}
          <Link href="/transactions">
            <Card className="cursor-pointer hover:shadow-lg transition-shadow h-full">
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Coins className="w-6 h-6 text-yellow-600" />
                  <CardTitle>Histórico de Transações</CardTitle>
                </div>
                <CardDescription>Veja seu histórico de compras e transações</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">Acompanhe todas as suas movimentações de coins</p>
              </CardContent>
            </Card>
          </Link>

          {/* Admin Panel */}
          {user?.role === "admin" && (
            <Link href="/admin">
              <Card className="cursor-pointer hover:shadow-lg transition-shadow h-full bg-gradient-to-br from-purple-50 to-purple-100">
                <CardHeader>
                  <div className="flex items-center gap-2 mb-2">
                    <BarChart3 className="w-6 h-6 text-purple-600" />
                    <CardTitle>Painel Admin</CardTitle>
                  </div>
                  <CardDescription>Gerencie produtos, usuários e configurações</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600">Acesso exclusivo para administradores</p>
                </CardContent>
              </Card>
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}

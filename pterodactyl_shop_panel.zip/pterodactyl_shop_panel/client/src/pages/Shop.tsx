import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Coins, Loader2, AlertCircle } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";

export default function Shop() {
  const { user } = useAuth();
  const { data: products, isLoading: productsLoading } = trpc.products.list.useQuery();
  const { data: balance } = trpc.coins.getBalance.useQuery();
  const buyMutation = trpc.servers.buy.useMutation();
  const [selectedProduct, setSelectedProduct] = useState<number | null>(null);

  const handleBuy = async (productId: number) => {
    try {
      const result = await buyMutation.mutateAsync({ productId });
      toast.success("Servidor criado com sucesso!");
      setSelectedProduct(null);
    } catch (error) {
      if (error instanceof Error) {
        toast.error(error.message);
      } else {
        toast.error("Erro ao criar servidor");
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <Link href="/">
              <Button variant="ghost" className="mb-4">← Voltar</Button>
            </Link>
            <h1 className="text-4xl font-bold text-slate-900">Loja de Servidores</h1>
            <p className="text-slate-600 mt-2">Compre servidores com seus coins</p>
          </div>
          <Card className="bg-yellow-50 border-yellow-200">
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <Coins className="w-6 h-6 text-yellow-500" />
                <div>
                  <p className="text-sm text-slate-600">Seu Saldo</p>
                  <p className="text-2xl font-bold text-slate-900">{balance?.balance || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Products Grid */}
        {productsLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          </div>
        ) : !products || products.length === 0 ? (
          <Card className="bg-slate-50 border-slate-200">
            <CardContent className="pt-12 pb-12 text-center">
              <AlertCircle className="w-12 h-12 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-slate-900 mb-2">Nenhum produto disponível</h3>
              <p className="text-slate-600">Os administradores ainda não criaram produtos para venda</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product) => (
              <Card key={product.id} className="hover:shadow-lg transition-shadow flex flex-col">
                <CardHeader>
                  <CardTitle>{product.name}</CardTitle>
                  <CardDescription>{product.description || "Sem descrição"}</CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <div className="space-y-3 mb-4">
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <p className="text-slate-600">Memória</p>
                        <p className="font-semibold text-slate-900">{product.memoryLimit}MB</p>
                      </div>
                      <div>
                        <p className="text-slate-600">Disco</p>
                        <p className="font-semibold text-slate-900">{product.diskLimit}MB</p>
                      </div>
                      <div>
                        <p className="text-slate-600">CPU</p>
                        <p className="font-semibold text-slate-900">{product.cpuLimit}%</p>
                      </div>
                      <div>
                        <p className="text-slate-600">Bancos de Dados</p>
                        <p className="font-semibold text-slate-900">{product.databasesLimit}</p>
                      </div>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-slate-600">Preço</span>
                      <div className="flex items-center gap-1">
                        <Coins className="w-5 h-5 text-yellow-500" />
                        <span className="text-2xl font-bold text-slate-900">{product.price}</span>
                      </div>
                    </div>

                    <Dialog open={selectedProduct === product.id} onOpenChange={(open) => {
                      if (!open) setSelectedProduct(null);
                    }}>
                      <DialogTrigger asChild>
                        <Button
                          className="w-full"
                          disabled={!balance || balance.balance < product.price}
                          onClick={() => setSelectedProduct(product.id)}
                        >
                          {!balance || balance.balance < product.price ? "Saldo Insuficiente" : "Comprar"}
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Confirmar Compra</DialogTitle>
                          <DialogDescription>
                            Você está prestes a comprar o servidor "{product.name}"
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div className="bg-slate-50 p-4 rounded-lg">
                            <div className="flex justify-between mb-2">
                              <span className="text-slate-600">Produto</span>
                              <span className="font-semibold text-slate-900">{product.name}</span>
                            </div>
                            <div className="flex justify-between mb-2">
                              <span className="text-slate-600">Preço</span>
                              <span className="font-semibold text-slate-900 flex items-center gap-1">
                                <Coins className="w-4 h-4 text-yellow-500" />
                                {product.price}
                              </span>
                            </div>
                            <div className="border-t pt-2 flex justify-between">
                              <span className="text-slate-600">Saldo Atual</span>
                              <span className="font-semibold text-slate-900">{balance?.balance || 0}</span>
                            </div>
                            <div className="border-t pt-2 flex justify-between">
                              <span className="text-slate-600">Saldo Após Compra</span>
                              <span className="font-semibold text-slate-900">
                                {(balance?.balance || 0) - product.price}
                              </span>
                            </div>
                          </div>

                          <div className="flex gap-3">
                            <Button
                              variant="outline"
                              className="flex-1"
                              onClick={() => setSelectedProduct(null)}
                            >
                              Cancelar
                            </Button>
                            <Button
                              className="flex-1"
                              disabled={buyMutation.isPending}
                              onClick={() => handleBuy(product.id)}
                            >
                              {buyMutation.isPending ? (
                                <>
                                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                  Processando...
                                </>
                              ) : (
                                "Confirmar Compra"
                              )}
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

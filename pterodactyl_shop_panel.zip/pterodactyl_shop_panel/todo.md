# Pterodactyl Shop Panel - TODO

## Banco de Dados
- [x] Schema: Tabela de usuários com role (admin/user) e coins
- [x] Schema: Tabela de produtos vinculados a eggs do Pterodactyl
- [x] Schema: Tabela de servidores criados com status
- [x] Schema: Tabela de transações (histórico de compras)
- [x] Schema: Tabela de configuração Pterodactyl (tokens, URL)

## Backend - Autenticação e Usuários
- [x] Endpoint para criar novo usuário admin
- [x] Endpoint para editar usuário admin
- [x] Endpoint para remover usuário admin
- [x] Endpoint para listar todos os usuários (admin only)
- [x] Endpoint para obter dados do usuário atual

## Backend - Sistema de Moedas
- [x] Endpoint para obter saldo de coins do usuário
- [x] Endpoint para adicionar coins (admin only)
- [x] Endpoint para remover coins (admin only)
- [x] Endpoint para registrar transação no histórico

## Backend - Produtos
- [x] Endpoint para criar produto (admin only)
- [x] Endpoint para editar produto (admin only)
- [x] Endpoint para deletar produto (admin only)
- [x] Endpoint para listar todos os produtos
- [x] Integração: Buscar eggs disponíveis do Pterodactyl

## Backend - Compra e Criação de Servidores
- [x] Endpoint para comprar produto (validar saldo, criar servidor)
- [x] Integração: Criar usuário no Pterodactyl se não existir
- [x] Integração: Criar servidor no Pterodactyl com egg do produto
- [x] Endpoint para listar servidores do usuário
- [x] Endpoint para obter status do servidor

## Backend - Transações
- [x] Endpoint para listar histórico de transações do usuário
- [x] Endpoint para listar todas as transações (admin only)

## Frontend - Autenticação
- [x] Página de login/logout
- [x] Verificação de role para acesso ao painel admin

## Frontend - Painel Admin
- [x] Dashboard admin com estatísticas
- [x] Gerenciamento de usuários admin (criar, editar, remover)
- [x] Gerenciamento de produtos (criar, editar, deletar)
- [x] Gerenciamento de coins dos usuários
- [x] Visualização de todas as transações

## Frontend - Loja
- [x] Página de loja com listagem de produtos
- [x] Exibição de preço em coins
- [x] Botão de compra com confirmação
- [x] Exibição de saldo de coins do usuário

## Frontend - Gerenciamento de Servidores
- [x] Página de meus servidores
- [x] Listagem de servidores criados
- [x] Exibição de status do servidor
- [x] Botão "Gerenciar Servidor" com redirecionamento para Pterodactyl
- [x] Informações básicas do servidor (nome, egg, recursos)

## Frontend - Histórico de Transações
- [x] Página de histórico de transações
- [x] Listagem com filtros (data, tipo)
- [x] Exibição de saldo antes/depois

## Configuração Pterodactyl
- [x] Adicionar campos para tokens Pterodactyl no banco
- [x] Endpoint para configurar tokens (admin only)
- [x] Validação de conexão com Pterodactyl

## Testes
- [x] Testes de autenticação
- [x] Testes de compra de servidor
- [x] Testes de integração com Pterodactyl
- [x] Testes de transações

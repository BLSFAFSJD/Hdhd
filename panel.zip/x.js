const axios = require('axios');

const PTERO_URL = 'https://painel.speed-sync.shop';
const API_KEY = 'ptla_E7xxA6H9Njq1GNBaTuTGatUYSI4kSOexZOkYfaGHjpp';

async function test() {
    const nests = await axios.get(`${PTERO_URL}/api/application/nests`, {
        headers: { Authorization: `Bearer ${API_KEY}`, Accept: 'Application/vnd.pterodactyl.v1+json' }
    });
    
    for (let nest of nests.data.data) {
        const eggs = await axios.get(`${PTERO_URL}/api/application/nests/${nest.attributes.id}/eggs?include=variables`, {
            headers: { Authorization: `Bearer ${API_KEY}`, Accept: 'Application/vnd.pterodactyl.v1+json' }
        });
        
        const egg3 = eggs.data.data.find(e => e.attributes.id == 3);
        if (egg3) {
            console.log('EGG 3 COMPLETO:', JSON.stringify(egg3, null, 2));
            break;
        }
    }
}

test();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const authRoutes = require('./routes/auth');

const app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

app.use('/api', authRoutes);
const fs = require('fs');

let users = JSON.parse(fs.readFileSync('./users.json', 'utf8'));
app.get('/api/my-servers/:id', (req, res) => {
    const userId = Number(req.params.id);

    const users = JSON.parse(fs.readFileSync('./database.json', 'utf8'));
    const user = users.find(u => u.id === userId);

    if (!user) return res.json([]);

    res.json(user.servers || []);
});
app.listen(3000, () => {
    console.log('Servidor rodando em http://localhost:3000');
});
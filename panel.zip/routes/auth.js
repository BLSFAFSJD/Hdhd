const express = require('express');
const router = express.Router();
const fs = require('fs');
const bcrypt = require('bcryptjs');
const axios = require('axios');

const DB_FILE = './database.json';

// 🔑 CONFIG PTERODACTYL
const PTERO_URL = 'https://painel.speed-sync.shop'; // ex: https://panel.seusite.com
const API_KEY = 'ptla_E7xxA6H9Njq1GNBaTuTGatUYSI4kSOexZOkYfaGHjpp';
const TURNSTILE_SECRET = '0x4AAAAAAC0mrP0ga4BlZeYJEfb_YXxu-mI';
async function verifyTurnstile(token, ip) {
    try {
        const res = await axios.post(
            'https://challenges.cloudflare.com/turnstile/v0/siteverify',
            new URLSearchParams({
                secret: TURNSTILE_SECRET,
                response: token,
                remoteip: ip
            })
        );

        return res.data.success;

    } catch (err) {
        console.log('❌ Erro captcha:', err.message);
        return false;
    }
}
// ler db
function readDB() {
    return JSON.parse(fs.readFileSync(DB_FILE));
}

// salvar db
function writeDB(data) {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

// 🚀 CRIAR USUÁRIO NO PTERODACTYL
async function createPteroUser(email) {
    try {
        const res = await axios.post(`${PTERO_URL}/api/application/users`, {
            email: email,
            username: email.split('@')[0],
            first_name: "User",
            last_name: "Ctrl",
            password: "12345678"
        }, {
            headers: {
                'Authorization': `Bearer ${API_KEY}`,
                'Content-Type': 'application/json',
                'Accept': 'Application/vnd.pterodactyl.v1+json'
            }
        });

        console.log('✅ Usuário criado no Pterodactyl:', res.data.attributes.id);

        return res.data.attributes.id;

    } catch (err) {
        console.log('❌ Erro ao criar no Pterodactyl:', err.response?.data || err.message);
        return null;
    }
}


router.post('/register', async (req, res) => {
const token = req.body['cf-turnstile-response'];

if (!token) {
    return res.status(400).json({ error: 'Captcha obrigatório' });
}

const isHuman = await verifyTurnstile(token, req.ip);

if (!isHuman) {
    return res.status(400).json({ error: 'Captcha inválido' });
}
    const { username, password } = req.body;

    let users = readDB();

    // ✅ VALIDAR SENHA (mínimo 8 caracteres)
    if (!password || password.length < 8) {
        return res.status(400).json({ error: 'A senha deve ter no mínimo 8 caracteres' });
    }

    // (opcional mas recomendado)
    if (!username || !username.includes('@')) {
        return res.status(400).json({ error: 'Email inválido' });
    }

    if (users.find(u => u.username === username)) {
        return res.status(400).json({ error: 'Usuário já existe' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    // 🧠 definir role
    const role = users.length === 0 ? 'admin' : 'member';

    console.log('Criando usuário...', username);
    console.log('Role:', role);

    // 🚀 criar no pterodactyl (apenas membros)
    let pteroId = null;

    if (role === 'member') {
        pteroId = await createPteroUser(username);
    }

    const newUser = {
        id: users.length + 1,
        username,
        password: hashedPassword,
        coins: 0,
        role,
        pteroId
    };

    users.push(newUser);
    writeDB(users);

    console.log('✅ Usuário salvo no JSON');

    res.json({
        message: 'Usuário criado!',
        role
    });
});

// 🔐 LOGIN
router.post('/login', async (req, res) => {
const token = req.body['cf-turnstile-response'];

if (!token) {
    return res.status(400).json({ error: 'Captcha obrigatório' });
}

const isHuman = await verifyTurnstile(token, req.ip);

if (!isHuman) {
    return res.status(400).json({ error: 'Captcha inválido' });
}
    const { username, password } = req.body;

    let users = readDB();

    const user = users.find(u => u.username === username);

    if (!user) {
        return res.status(400).json({ error: 'Usuário não encontrado' });
    }

    const valid = await bcrypt.compare(password, user.password);

    if (!valid) {
        return res.status(400).json({ error: 'Senha incorreta' });
    }

    console.log('✅ Login:', username);

    res.json({
        message: 'Login OK',
        user
    });
});


// 📋 LISTAR USUÁRIOS (admin)
router.get('/users', (req, res) => {
    let users = readDB();
    res.json(users);
});

// 💰 ADICIONAR COINS
router.post('/add-coins', async (req, res) => {

    const { userId, coins } = req.body;

    let users = readDB();
    let user = users.find(u => u.id == userId);

    if (!user) return res.status(404).json({ error: 'Usuário não encontrado' });

    user.coins += Number(coins);

    writeDB(users);

    console.log(`💰 Coins adicionados: ${coins} para ${user.username}`);

    res.json({ message: 'Coins adicionados' });
});

// 👑 PROMOVER / REMOVER ADMIN
router.post('/set-role', (req, res) => {
    const { userId, role } = req.body;

    let users = readDB();
    let user = users.find(u => u.id == userId);

    if (!user) return res.status(404).json({ error: 'Usuário não encontrado' });

    user.role = role;

    writeDB(users);

    console.log(`🔄 Role alterada: ${user.username} -> ${role}`);

    res.json({ message: 'Role atualizada' });
});

// =======================
// 🔗 PTERODACTYL DATA
// =======================

// 📡 PEGAR NODES
router.get('/nodes', async (req,res)=>{
    try{
        const r = await axios.get(`${PTERO_URL}/api/application/nodes`, {
            headers:{
                Authorization: `Bearer ${API_KEY}`,
                Accept: 'Application/vnd.pterodactyl.v1+json'
            }
        });

        res.json(r.data.data);

    }catch(err){
        console.log('❌ nodes:', err.response?.data || err.message);
        res.status(500).json({error:'Erro ao buscar nodes'});
    }
});


// 📡 PEGAR EGGS
router.get('/eggs', async (req,res)=>{
    try{
        const nests = await axios.get(`${PTERO_URL}/api/application/nests`, {
            headers:{
                Authorization: `Bearer ${API_KEY}`,
                Accept: 'Application/vnd.pterodactyl.v1+json'
            }
        });

        let allEggs = [];

        for (let nest of nests.data.data){
            const eggs = await axios.get(`${PTERO_URL}/api/application/nests/${nest.attributes.id}/eggs`, {
                headers:{
                    Authorization: `Bearer ${API_KEY}`,
                    Accept: 'Application/vnd.pterodactyl.v1+json'
                }
            });

            eggs.data.data.forEach(e=>{
                allEggs.push({
                    id: e.attributes.id,
                    name: e.attributes.name
                });
            });
        }

        res.json(allEggs);

    }catch(err){
        console.log('❌ eggs:', err.response?.data || err.message);
        res.status(500).json({error:'Erro ao buscar eggs'});
    }
});

// =======================
// 📦 PRODUTOS
// =======================

const PRODUCTS_FILE = './products.json';

function readProducts(){
    return JSON.parse(fs.readFileSync(PRODUCTS_FILE));
}

function writeProducts(data){
    fs.writeFileSync(PRODUCTS_FILE, JSON.stringify(data, null, 2));
}

// CRIAR PRODUTO
router.post('/create-product', async (req, res) => {

    const { name, description, price, cpu, memory, disk, node, egg } = req.body;

    // Validar dados
    if(!name || !price || !cpu || !memory || !disk || !node || !egg){
        return res.status(400).json({ error: 'Todos os campos sao obrigatorios' });
    }

    let products = readProducts();

    const newProduct = {
        id: products.length + 1,
        name,
        description,
        price: Number(price),
        cpu: Number(cpu),
        memory: Number(memory),
        disk: Number(disk),
        node: Number(node),
        egg: Number(egg)
    };

    products.push(newProduct);
    writeProducts(products);

    console.log('📦 Produto criado:', name);

    res.json({ message: 'Produto criado!' });
});

// 🔌 Função para buscar uma alocação livre no Node
// 🔌 Função para buscar uma alocação livre no Node
async function getFreeAllocation(nodeId) {
    try {
        console.log(`🔍 Buscando alocações com domínio no node ${nodeId}...`);
        
        const response = await axios.get(`${PTERO_URL}/api/application/nodes/${nodeId}/allocations`, {
            headers: {
                Authorization: `Bearer ${API_KEY}`,
                Accept: 'Application/vnd.pterodactyl.v1+json'
            }
        });

        const freeAlloc = response.data.data.find(a => 
            a.attributes.assigned === false &&
            a.attributes.alias &&                      // tem domínio
            a.attributes.ip !== "0.0.0.0"              // não é IP vazio
        );

        if (freeAlloc) {
            console.log(`✅ Allocation correta: ${freeAlloc.attributes.alias}:${freeAlloc.attributes.port}`);
            return {
                id: freeAlloc.attributes.id,
                port: freeAlloc.attributes.port
            };
        }

        throw new Error('Nenhuma allocation com domínio disponível');

    } catch (err) {
        console.error('❌ Erro ao buscar allocation:', err.response?.data || err.message);
        throw err;
    }
}
router.post('/buy-server', async (req, res) => {

    const { userId, productId, serverName } = req.body;

    let users = readDB();
    let products = readProducts();

    let user = users.find(u => u.id == userId);
    let product = products.find(p => p.id == productId);

    if (!user || !product) {
        return res.json({ error: 'Usuário ou produto não encontrado' });
    }

    // ✅ VALIDAR NOME
    if (!serverName || serverName.trim().length < 3) {
        return res.json({ error: 'Nome do servidor inválido' });
    }

    const cleanName = serverName.trim().substring(0, 40);

    // ✅ VERIFICAR DUPLICADO NO USUÁRIO
    if (user.servers && user.servers.find(s => s.name.toLowerCase() === cleanName.toLowerCase())) {
        return res.json({ error: 'Você já tem um servidor com esse nome' });
    }

    if (user.coins < product.price) {
        return res.json({ error: 'Coins insuficientes' });
    }

    // Criar pteroId se não existir
    if (!user.pteroId) {
        try {
            const pteroUser = await createPteroUser(user.username);
            if (!pteroUser) {
                return res.json({ error: 'Erro ao criar conta no Pterodactyl' });
            }
            user.pteroId = pteroUser;
            writeDB(users);
        } catch (err) {
            return res.json({ error: 'Erro ao criar conta no Pterodactyl' });
        }
    }

    try {
        // ✅ VERIFICAR DUPLICADO NO PTERODACTYL
        try {
            const existingServers = await axios.get(`${PTERO_URL}/api/application/servers`, {
                headers: {
                    Authorization: `Bearer ${API_KEY}`,
                    Accept: 'Application/vnd.pterodactyl.v1+json'
                }
            });

            const nameExists = existingServers.data.data.find(s =>
                s.attributes.name.toLowerCase() === cleanName.toLowerCase()
            );

            if (nameExists) {
                return res.json({ error: 'Nome já está em uso, escolha outro' });
            }

        } catch (err) {
            console.log('⚠️ Erro ao verificar nomes:', err.message);
        }

        // 🔍 Buscar informações do Egg
        let eggData = null;

        const nestsResponse = await axios.get(`${PTERO_URL}/api/application/nests`, {
            headers: {
                Authorization: `Bearer ${API_KEY}`,
                Accept: 'Application/vnd.pterodactyl.v1+json'
            }
        });

        for (let nest of nestsResponse.data.data) {
            const eggsResponse = await axios.get(
                `${PTERO_URL}/api/application/nests/${nest.attributes.id}/eggs?include=variables`,
                {
                    headers: {
                        Authorization: `Bearer ${API_KEY}`,
                        Accept: 'Application/vnd.pterodactyl.v1+json'
                    }
                }
            );

            const foundEgg = eggsResponse.data.data.find(e => e.attributes.id == product.egg);

            if (foundEgg) {
                eggData = foundEgg.attributes;
                break;
            }
        }

        if (!eggData) {
            return res.json({ error: 'Egg não encontrado' });
        }

        const dockerImage = eggData.docker_image || 'ghcr.io/pterodactyl/yolks:nodejs_18';
        const startupCommand = eggData.startup || 'npm start';

        // Environment
        let environment = {};

        if (eggData.relationships?.variables?.data) {
            for (let varItem of eggData.relationships.variables.data) {
                const varAttr = varItem.attributes;
                const envKey = varAttr.env_variable;
                if (envKey) {
                    environment[envKey] = (varAttr.default_value || "").toString();
                }
            }
        }

        if (!environment.BUNGEE_VERSION) environment.BUNGEE_VERSION = "latest";
        if (!environment.SERVER_JARFILE) environment.SERVER_JARFILE = "bungeecord.jar";

        // 🔌 Buscar alocação livre
        const alloc = await getFreeAllocation(product.node);
        const allocationId = alloc.id;
        const serverPort = alloc.port;

        // 🚀 Criar servidor com NOME PERSONALIZADO
        const createPayload = {
            name: cleanName,
            user: user.pteroId,
            egg: parseInt(product.egg),
            docker_image: dockerImage,
            startup: startupCommand,
            environment: environment,
            limits: {
                memory: parseInt(product.memory),
                swap: 0,
                disk: parseInt(product.disk),
                io: 500,
                cpu: parseInt(product.cpu)
            },
            feature_limits: {
                databases: 0,
                backups: 0,
                allocations: 1
            },
            allocation: {
                default: parseInt(allocationId)
            }
        };

        const response = await axios.post(
            `${PTERO_URL}/api/application/servers`,
            createPayload,
            {
                headers: {
                    Authorization: `Bearer ${API_KEY}`,
                    'Content-Type': 'application/json',
                    Accept: 'Application/vnd.pterodactyl.v1+json'
                }
            }
        );

        const serverUuid = response.data.attributes.uuid;
        const serverId = response.data.attributes.id;

        // Alias (opcional)
        try {
            await axios.post(
                `${PTERO_URL}/api/application/servers/${serverId}/aliases`,
                {
                    alias: `node.speed-sync.shop:${serverPort}`
                },
                {
                    headers: {
                        Authorization: `Bearer ${API_KEY}`,
                        'Content-Type': 'application/json',
                        Accept: 'Application/vnd.pterodactyl.v1+json'
                    }
                }
            );
        } catch (err) {
            console.log('⚠️ Erro ao adicionar alias:', err.message);
        }

        // 💰 Descontar coins
        user.coins -= product.price;

        if (!user.servers) user.servers = [];

        // ✅ SALVAR NOME PERSONALIZADO
        user.servers.push({
            id: serverUuid,
            name: cleanName
        });

        writeDB(users);

        return res.json({
            message: 'Servidor criado com sucesso!',
            serverUuid
        });

    } catch (err) {
        console.error('❌ ERRO AO CRIAR SERVIDOR:', err.response?.data || err.message);

        const errorDetail =
            err.response?.data?.errors?.[0]?.detail ||
            err.message ||
            'Erro desconhecido ao criar servidor';

        return res.json({ error: errorDetail });
    }
});
// LISTAR PRODUTOS
router.get('/products', (req,res)=>{
    res.json(readProducts());
});

module.exports = router;
